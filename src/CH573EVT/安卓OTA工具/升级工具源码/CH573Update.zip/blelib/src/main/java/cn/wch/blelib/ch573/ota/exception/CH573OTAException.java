package cn.wch.blelib.ch573.ota.exception;

public class CH573OTAException extends Exception {
    public CH573OTAException(String message) {
        super(message);
    }
}
