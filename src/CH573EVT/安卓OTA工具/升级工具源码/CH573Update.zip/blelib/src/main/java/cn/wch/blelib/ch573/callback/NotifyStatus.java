package cn.wch.blelib.ch573.callback;

public interface NotifyStatus {
    void onData(byte[] data);
}
